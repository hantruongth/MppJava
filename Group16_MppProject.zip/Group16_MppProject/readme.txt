Our group number is 16.

#Login information:
- Admin: admin,			Password: 123456
- Librarian: lib,		Password: 123456
- Super Admin: both,	Password: 123456


We already solved all problems including the optional extra parts. 

All source code, data , documents: https://github.com/chalovina/Group16/tree/master/Group16_MppProject

Demo video: https://www.youtube.com/watch?v=DoL4I_s_dPo

To Run the program, simply to execute RUN.bat in the "Jar Execution" folder.