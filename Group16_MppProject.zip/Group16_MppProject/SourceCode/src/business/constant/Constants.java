package business.constant;

public class Constants {
	public static final int MAX_DAY_BOOK_BORROWING = 21;

}
