package business.util;

public class Utils {

	public static final boolean isEmpty(String str) {
		return str == null || str.isEmpty();
	}

}
